import joblib

model=joblib.load('model_final')

print(model.predict([[66,105.65,0,1,0,0,0,0,1,0]])[0])
